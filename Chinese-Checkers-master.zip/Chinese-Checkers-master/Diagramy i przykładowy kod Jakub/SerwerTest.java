package chinskie.warcaby;

import static org.junit.Assert.*;

import org.junit.Test;

public class SerwerTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
