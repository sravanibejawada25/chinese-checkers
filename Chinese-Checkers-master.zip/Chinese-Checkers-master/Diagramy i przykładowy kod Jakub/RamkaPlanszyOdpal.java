package chinskie.warcaby;

import java.awt.EventQueue;

public class RamkaPlanszyOdpal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EventQueue.invokeLater(new Runnable() {

			public void run() {
				new RamkaPlanszy();
			}
		});

	}

}
