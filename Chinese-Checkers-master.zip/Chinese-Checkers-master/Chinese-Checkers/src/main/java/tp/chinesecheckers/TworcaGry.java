package tp.chinesecheckers;

/**
 * 
 * @author mdlot
 *
 */
public abstract class TworcaGry {
  
  /**
   * Tworzy gr� na podstawie wcze�niej podanych ustawie�.
   * @return Stworzona gra.
   */
  public abstract Gra stworzGre();
  
}
