package tp.chinesecheckers.exception;

/**
 * 
 * @author mdlot
 *
 */
public class NiepoprawnyRuch extends Exception {

  /**
   * Konstruktor.
   */
  public NiepoprawnyRuch() {}
}
