package tp.chinesecheckers;

/**
 * Kierunki tworzenia pionk�w zawodnika.
 * @author mdlot
 *
 */
public enum KierunekTworzeniaPionkow {
  N,
  S,
  NW,
  NE,
  SW,
  SE
}
