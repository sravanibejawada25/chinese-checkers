package tp.chinesecheckers.klient;

import org.junit.runners.Parameterized;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import java.awt.Graphics2D;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
 
public class PionyTest {

	
	;

}
