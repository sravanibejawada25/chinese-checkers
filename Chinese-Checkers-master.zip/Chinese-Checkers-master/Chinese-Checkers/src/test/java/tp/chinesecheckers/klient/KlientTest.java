package tp.chinesecheckers.klient;

import static org.junit.Assert.*;

import org.junit.Test;

public class KlientTest {

  @Test
  public void test() {
    fail("Not yet implemented");
  }

}
